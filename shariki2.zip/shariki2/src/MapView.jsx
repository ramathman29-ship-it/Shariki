import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";

export default function MapView({ lat, lng, title, address }) {
     if (!lat || !lng)
         return
         <p>📍 Location not available</p>;
          const position = [lat, lng];
           return (
             <div style={{ height: "350px", width: "100%", borderRadius: "10px", overflow: "hidden" }}>
                 <MapContainer center={position} zoom={15} style={{ height: "100%", width: "100%" }}>
                     <TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                      <Marker position={position}> <Popup> <b>{title}</b> <br /> {address} </Popup> </Marker> </MapContainer> </div> );
                       }