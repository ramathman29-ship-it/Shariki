export default function MyHouses(){
    return(
        <p>your houses gose here</p>
    )
}